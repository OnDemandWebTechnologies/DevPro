<?php
/**
 *
 * Devpro Framework
 *
 * @author Devpro
 * @license Commercial License
 * @link https://ondemandwebtech.com
 * @copyright 2014 Devpro Themes
 * @package CSFramework
 * @version 1.0.0
 *
 */
locate_template('cs-framework/init.php', true);

include_once 'login/functions.php';