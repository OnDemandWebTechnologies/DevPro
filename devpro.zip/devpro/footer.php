      </div><!-- /content -->

    </div><!-- /main -->

    <?php echo cs_footer_area(); ?><!-- /footer -->

  </div><!-- /page -->

  <?php echo cs_custom_js(); ?>
  <?php wp_footer(); ?>

  </body>
</html>