<header id="masthead" role="banner">
  <div class="container">
    <div class="cs-inner">
      <?php echo cs_site_logo(); ?><!-- /site-logo -->
      <?php echo cs_site_menu(); ?><!-- /site-nav -->
      <?php echo cs_mobile_icon(); ?><!-- /mobile-icon -->
    </div>
  </div>
  <div id="site-header-shadow"></div>
</header><!-- /header -->