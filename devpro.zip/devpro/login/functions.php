<?php
function my_custom_login() {
	echo '<link rel="stylesheet" type="text/css" href="' . get_bloginfo('stylesheet_directory') . '/login/style.css" />';
}
add_action('login_head', 'my_custom_login');